package org.jvnet.jaxbw.eclipse.popup.actions;

import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.*;
import java.util.logging.Logger;

import org.eclipse.core.resources.*;
import org.eclipse.core.runtime.*;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.window.Window;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.*;
import org.eclipse.ui.progress.IProgressService;
import org.jvnet.jaxbw.eclipse.*;
import org.jvnet.jaxbw.eclipse.FileInfo.LineInfo;
import org.jvnet.jaxbw.eclipse.FileInfo.MessageInfo;

import com.sun.tools.xjc.Driver;

public class RunXjcAction implements IObjectActionDelegate {
	/**
	 * Current selection in the project tree.
	 */
	protected ISelection selection;

	/**
	 * Is used to remove all markers for a given resource.
	 */
	protected static Map<IResource, List<IMarker>> markers = new HashMap<IResource, List<IMarker>>();

	/**
	 * XJC runnable. Is launched on the specified main schema and additional
	 * parameters (package name, output directory, ...)
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected static class XjcRunnable implements IRunnableWithProgress {
		/**
		 * Logger object.
		 */
		private final Logger _logger = Logger.getLogger(XjcRunnable.class
				.getName());

		/**
		 * All messages of XJC.
		 */
		private Map<String, FileInfo> xjcMessages = null;

		/**
		 * Input XJC settings.
		 */
		private String[] xjcSettings;

		private Shell shell;

		protected XjcHarvesterListener listener;

		protected boolean cancelled;

		public XjcRunnable(Shell shell, String[] settings) {
			this.shell = shell;
			xjcSettings = settings;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.eclipse.jface.operation.IRunnableWithProgress#run(org.eclipse.core.runtime.IProgressMonitor)
		 */
		public void run(IProgressMonitor monitor)
				throws InvocationTargetException, InterruptedException {
			listener = new XjcHarvesterListener(monitor);
			try {
				Enumeration<URL> urls = RunXjcAction.class.getClassLoader()
						.getResources("javax/xml/namespace/QName.class");
				while (urls.hasMoreElements()) {
					URL url = urls.nextElement();
					_logger.info(url.toString());
				}

				Driver.run(this.xjcSettings, listener);
			} catch (Exception exc) {
				MessageDialog.openInformation(this.shell, "Jaxbw Plug-in", exc
						.getMessage());
			}
			this.xjcMessages = listener.getMessages();
		}

		/**
		 * Returns a collection of XJC messages.
		 * 
		 * @return Collection of XJC messages.
		 */
		public Map<String, FileInfo> getXjcMessages() {
			return Collections.unmodifiableMap(xjcMessages);
		}
	}

	/**
	 * Constructor for RunXjcAction.
	 */
	public RunXjcAction() {
		super();
	}

	/**
	 * @see IObjectActionDelegate#setActivePart(IAction, IWorkbenchPart)
	 */
	public void setActivePart(IAction action, IWorkbenchPart targetPart) {
	}

	/**
	 * @see IActionDelegate#run(IAction)
	 */
	public void run(IAction action) {
		if (selection instanceof IStructuredSelection) {
			for (Iterator it = ((IStructuredSelection) selection).iterator(); it
					.hasNext();) {
				Object element = it.next();
				IResource resource = null;
				if (element instanceof IResource) {
					resource = (IResource) element;
				} else if (element instanceof IAdaptable) {
					resource = (IProject) ((IAdaptable) element)
							.getAdapter(IProject.class);
				} else {
				}
				if (resource != null) {
					run(resource);
				}
			}
		} else {
			// Not structured selection
		}
	}

	protected void run(IResource resource) {
		final Shell shell = new Shell();
		try {
			// get the project and workspace.
			IProject project = resource.getProject();
			IWorkspace workspace = resource.getWorkspace();

			String fileLocation = resource.getLocation().toOSString();

			XjcWizard wizard = new XjcWizard(resource);
			WizardDialog dialog = new WizardDialog(Display.getCurrent()
					.getActiveShell(), wizard);
			int wizardStatus = dialog.open();
			if (wizardStatus == Window.OK) {
				XjcRunnable xjcRunnable = new XjcRunnable(shell, wizard
						.getXjcSettings());
				IProgressService progressService = PlatformUI.getWorkbench()
						.getProgressService();
				progressService.run(true, true, xjcRunnable);

				// remove all existing markers on this resource
				List<IMarker> existingMarkers = markers.get(resource);
				if (existingMarkers != null) {
					workspace.deleteMarkers(existingMarkers
							.toArray(new IMarker[0]));
				}
				// remove all existing markers on a file with the same name
				IMarker[] problems = null;
				int depth = IResource.DEPTH_INFINITE;
				problems = resource.findMarkers(IMarker.PROBLEM, true, depth);
				existingMarkers = new LinkedList<IMarker>();
				for (IMarker marker : problems) {
					String problemFileName = marker.getResource().getLocation()
							.toOSString();
					if (problemFileName.equals(fileLocation))
						existingMarkers.add(marker);
				}
				workspace
						.deleteMarkers(existingMarkers.toArray(new IMarker[0]));

				// see if we had problems
				Map<String, FileInfo> messageMap = xjcRunnable.getXjcMessages();
				List<IMarker> newMarkers = new LinkedList<IMarker>();
				for (Map.Entry<String, FileInfo> entry : messageMap.entrySet()) {
					String fileName = entry.getKey();
					FileInfo fInfo = entry.getValue();
					if (fileName.equals(fileLocation)) {
						for (LineInfo lInfo : fInfo.getMessages()) {
							for (MessageInfo mInfo : lInfo.getMessages()) {
								IMarker marker = resource
										.createMarker(IMarker.PROBLEM);
								if (marker.exists()) {
									marker.setAttribute(IMarker.MESSAGE,
											"XJC : " + mInfo.getText());
									marker.setAttribute(IMarker.LINE_NUMBER,
											mInfo.getLineNumber());
								}
								switch (mInfo.getKind()) {
								case ERROR:
									marker.setAttribute(IMarker.PRIORITY,
											IMarker.PRIORITY_HIGH);
									marker.setAttribute(IMarker.SEVERITY,
											IMarker.SEVERITY_ERROR);
									break;
								case WARNING:
									marker.setAttribute(IMarker.PRIORITY,
											IMarker.PRIORITY_NORMAL);
									marker.setAttribute(IMarker.SEVERITY,
											IMarker.SEVERITY_WARNING);
									break;
								case INFO:
									marker.setAttribute(IMarker.PRIORITY,
											IMarker.PRIORITY_LOW);
									marker.setAttribute(IMarker.SEVERITY,
											IMarker.SEVERITY_INFO);
									break;
								}
								marker.setAttribute(IMarker.TRANSIENT, true);
								newMarkers.add(marker);
							}
						}
					}
				}
				markers.put(resource, newMarkers);

				IPathVariableManager pathMan = workspace
						.getPathVariableManager();
				String name = "TEMP";
				IPath value = new Path(wizard.getOutputDir());
				if (pathMan.validateName(name).isOK()
						&& pathMan.validateValue(value).isOK()) {
					pathMan.setValue(name, value);
				} else {
					// invalid name or value, throw an exception or warn user
				}

				IFolder link = project.getFolder("Link");
				IPath location = new Path("TEMP/.");
				if (workspace.validateLinkLocation(resource, location).isOK()) {
					link.createLink(location, IResource.NONE, null);
				} else {
					// invalid location, throw an exception or warn user
				}

				link.refreshLocal(IResource.DEPTH_INFINITE, null);
			}
		} catch (Exception exc) {
			IStatus status = new Status(IStatus.ERROR,
					"org.jvnet.jaxbw.eclipse", IStatus.OK,
					exc.getMessage() == null ? "" : exc.getMessage(), exc);
			ErrorDialog.openError(shell, "Jaxbw Plug-in", exc.getMessage(),
					status);
			exc.printStackTrace();
		}
		// IFolder gen = project.getFolder("gen");

		// IWorkspace workspace = ResourcesPlugin.getWorkspace();
		// try {
		// workspace.run(xjcRunnable, resource.getProject(),
		// IWorkspace.AVOID_UPDATE, null);
		// } catch (Exception exc) {
		// MessageDialog.openInformation(shell, "Jaxbw Plug-in", exc
		// .getMessage());
		// }

		// public IStatus run(IProgressMonitor monitor) {
		// final int ticks = 6000;
		// monitor.beginTask("Doing some work", ticks);
		// try {
		// for (int i = 0; i < ticks; i++) {
		// if (monitor.isCanceled())
		// return Status.CANCEL_STATUS;
		// monitor.subTask("Processing tick #" + i);
		// // ... do some work ...
		// monitor.worked(1);
		// }
		// } finally {
		// monitor.done();
		// }
		// return Status.OK_STATUS;
		//				
	}

	/**
	 * @see IActionDelegate#selectionChanged(IAction, ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection) {
		this.selection = selection;
	}

}
