package org.jvnet.jaxbw.eclipse;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.jface.dialogs.IMessageProvider;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.*;

public class WizardSelectMandatoryPage extends WizardPage implements Listener {

	protected Text packageNameText;

	protected String initialPackageName;

	protected Text outputDirText;

	protected Button outputDirButton;

	protected String initialOutputDirectory;

	protected final Pattern packagePattern;

	public WizardSelectMandatoryPage(String initialPackageName,
			String initialOutputDirectory) {
		super("XJC mandatory parameters");
		this.setTitle("XJC mandatory parameters");
		this.initialPackageName = initialPackageName;
		this.initialOutputDirectory = initialOutputDirectory;

		// pattern for package name (loosely follows JLS 3.8 and 7.7),
		// allowing keywords to be part of package names (will be
		// caught later by XJC)
		this.packagePattern = Pattern
				.compile("[_$a-zA-Z][_$0-9a-zA-Z]*(\u002E[_$a-zA-Z][_$0-9a-zA-Z]*)*");
	}

	public void createControl(Composite parent) {
		final Group group = new Group(parent, SWT.NONE);
		GridLayout layout = new GridLayout();
		layout.numColumns = 3;
		group.setLayout(layout);

		Label labelPackageName = new Label(group, SWT.NONE);
		labelPackageName.setText("Package name");

		this.packageNameText = new Text(group, SWT.BORDER);
		this.packageNameText.setText(initialPackageName);
		this.packageNameText.addListener(SWT.KeyUp, this);

		Label labelOutputDir = new Label(group, SWT.NONE);
		labelOutputDir.setText("Output directory");

		this.outputDirButton = new Button(group, SWT.PUSH);
		this.outputDirButton.setText("Change");
		this.outputDirButton.addListener(SWT.Selection, new Listener() {
			public void handleEvent(Event event) {
				DirectoryDialog directoryDialog = new DirectoryDialog(group
						.getShell());
				directoryDialog.setFilterPath(getOutputDir());
				directoryDialog
						.setMessage("Please select a directory and click OK");
				String dir = directoryDialog.open();
				if (dir != null) {
					outputDirText.setText(dir);
				}
				setPageComplete(isPageComplete());
			}
		});
		this.outputDirText = new Text(group, SWT.BORDER);
		if (initialOutputDirectory != null)
			this.outputDirText.setText(initialOutputDirectory);
		this.outputDirText.setEditable(false);
		this.outputDirText.addListener(SWT.KeyUp, this);

		GridData data = new GridData();
		data.widthHint = 120;
		labelPackageName.setLayoutData(data);
		data = new GridData();
		data.widthHint = 120;
		labelOutputDir.setLayoutData(data);

		GridData data2 = new GridData(GridData.FILL_HORIZONTAL);
		data2.horizontalSpan = 2;
		this.packageNameText.setLayoutData(data2);
		
		GridData data3 = new GridData();
		data3.widthHint = 60;
		this.outputDirButton.setLayoutData(data3);
		data2 = new GridData(GridData.FILL_HORIZONTAL);
		data2.horizontalSpan = 1;
		this.outputDirText.setLayoutData(data2);

		setPageComplete(isPageComplete());

		this.setControl(group);
	}

	@Override
	public Control getControl() {
		return super.getControl();
	}

	public void handleEvent(Event event) {
		setPageComplete(isPageComplete());
	}

	@Override
	public boolean isPageComplete() {
		String packageName = this.getPackageName();
		if (packageName == null) {
			this.setMessage("Package name can not be null",
					IMessageProvider.ERROR);
			return false;
		}
		if (packageName.length() == 0) {
			this.setMessage("Package name can not be empty",
					IMessageProvider.ERROR);
			return false;
		}
		Matcher m = this.packagePattern.matcher(packageName);
		boolean isMatch = m.matches();
		if (!isMatch) {
			this
					.setMessage("Package name is not valid",
							IMessageProvider.ERROR);
			return false;
		} else {
			this.setMessage(null);
		}

		String outputDir = this.getOutputDir();
		if (outputDir == null) {
			this.setMessage("Output directory can not be null",
					IMessageProvider.ERROR);
			return false;
		}
		if (outputDir.length() == 0) {
			this.setMessage("Output directory can not be empty",
					IMessageProvider.ERROR);
			return false;
		}
		return true;
	}

	public String getPackageName() {
		return this.packageNameText.getText();
	}

	public String getOutputDir() {
		return this.outputDirText.getText();
	}
}
