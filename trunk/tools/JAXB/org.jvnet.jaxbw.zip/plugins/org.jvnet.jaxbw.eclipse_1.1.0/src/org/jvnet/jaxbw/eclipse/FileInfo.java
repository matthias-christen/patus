/*
 * Copyright (c) 2005-2006 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.jaxbw.eclipse;

import java.util.*;

/**
 * Contains information on a single file (with associated messages if exist).
 * 
 * @author Kirill Grouchnikov
 */
public final class FileInfo {
	/**
	 * Name of the associated file.
	 */
	private final String fileName;

	/**
	 * Messages. Key - line number, value - a list of messages associated with
	 * this line. Note that there can be more than one message per line.
	 */
	private final Map<Integer, LineInfo> messages;

	/**
	 * Enum for message severity.
	 * 
	 * @author Kirill Grouchnikov
	 */
	public static enum MessageKind {
		/**
		 * Error severity.
		 */
		ERROR(0) {
		},
		/**
		 * Warning severity.
		 */
		WARNING(1) {
		},
		/**
		 * Info severity.
		 */
		INFO(2) {
		},
		/**
		 * Success severity.
		 */
		SUCCESS(3) {
		};

		/**
		 * Message severity (for sorting in
		 * {@link #compare(MessageKind, MessageKind)}).
		 */
		private int severity;

		/**
		 * Simple constructor.
		 * 
		 * @param severity
		 *            Relative severity.
		 */
		MessageKind(int severity) {
			this.severity = severity;
		}

	}

	/**
	 * Information on a single message.
	 * 
	 * @author Kirill Grouchnikov
	 */
	public static final class MessageInfo {
		/**
		 * Message line number.
		 */
		private int lineNumber;

		/**
		 * Message severity.
		 */
		private MessageKind kind;

		/**
		 * Message text.
		 */
		private String text;

		/**
		 * Simple constructor.
		 * 
		 * @param lineNumber
		 *            Message line number.
		 * @param kind
		 *            Message severity.
		 * @param text
		 *            Message text.
		 */
		public MessageInfo(int lineNumber, MessageKind kind, String text) {
			this.lineNumber = lineNumber;
			this.kind = kind;
			this.text = text;
		}

		/**
		 * Retrieves the message line number of <code>this</code> info object.
		 * 
		 * @return Message line number of <code>this</code> info object.
		 */
		public int getLineNumber() {
			return lineNumber;
		}

		/**
		 * Retrieves the message severity of <code>this</code> info object.
		 * 
		 * @return Message severity of <code>this</code> info object.
		 */
		public MessageKind getKind() {
			return kind;
		}

		/**
		 * Retrieves the message text of <code>this</code> info object.
		 * 
		 * @return Message text of <code>this</code> info object.
		 */
		public String getText() {
			return text;
		}
	}

	/**
	 * Contains information on messages in one line of some file.
	 * 
	 * @author Kirill Grouchnikov
	 */
	public static final class LineInfo {
		/**
		 * The line number associated with all messages.
		 */
		private final int lineNumber;

		/**
		 * The list of messages for this line.
		 */
		private final List<MessageInfo> messages;

		/**
		 * Simple constructor.
		 * 
		 * @param lineNumber
		 *            The line number associated with all messages.
		 */
		public LineInfo(int lineNumber) {
			this.lineNumber = lineNumber;
			this.messages = new LinkedList<MessageInfo>();
		}

		/**
		 * Returns the messages of <code>this</code> object.
		 * 
		 * @return The messages of <code>this</code> object.
		 */
		public final List<MessageInfo> getMessages() {
			return messages;
		}

		/**
		 * Returns the line number of <code>this</code> object.
		 * 
		 * @return The line number of <code>this</code> object.
		 */
		public final int getLineNumber() {
			return lineNumber;
		}

		/**
		 * Adds new messages to <code>this</code> object.
		 * 
		 * @param text
		 *            New message to add.
		 */
		public final MessageInfo addMessage(MessageKind kind, String text) {
			MessageInfo newMessage = new MessageInfo(this.lineNumber, kind,
					text);
			this.messages.add(newMessage);
			return newMessage;
		}
	}

	/**
	 * Simple constructor.
	 * 
	 * @param fileName
	 *            File name.
	 */
	public FileInfo(String fileName) {
		this.fileName = fileName;
		this.messages = new HashMap<Integer, LineInfo>();
	}

	/**
	 * Returns the file name of <code>this</code> object.
	 * 
	 * @return The file name of <code>this</code> object.
	 */
	public final String getFileName() {
		return fileName;
	}

	/**
	 * Adds new message for specified line.
	 * 
	 * @param line
	 *            Line of message.
	 * @param message
	 *            The message itself.
	 */
	public final synchronized void addError(int line, String message) {
		if (!this.messages.containsKey(line)) {
			LineInfo newInfo = new LineInfo(line);
			this.messages.put(line, newInfo);
		}
		LineInfo ei = this.messages.get(line);
		ei.addMessage(MessageKind.ERROR, message);
	}

	/**
	 * Adds new message for specified line.
	 * 
	 * @param line
	 *            Line of message.
	 * @param message
	 *            The message itself.
	 */
	public final synchronized void addWarning(int line, String message) {
		if (!this.messages.containsKey(line)) {
			LineInfo newInfo = new LineInfo(line);
			this.messages.put(line, newInfo);
		}
		LineInfo ei = this.messages.get(line);
		ei.addMessage(MessageKind.WARNING, message);
	}

	/**
	 * Adds new message for specified line.
	 * 
	 * @param line
	 *            Line of message.
	 * @param message
	 *            The message itself.
	 */
	public final synchronized MessageInfo addMessage(int line,
			MessageKind kind, String message) {
		if (!this.messages.containsKey(line)) {
			LineInfo newInfo = new LineInfo(line);
			this.messages.put(line, newInfo);
		}
		LineInfo ei = this.messages.get(line);
		return ei.addMessage(kind, message);
	}

	/**
	 * Returns all the messages of the associated file.
	 * 
	 * @return The messages of the associated file.
	 */
	public final synchronized Collection<LineInfo> getMessages() {
		return this.messages.values();
	}

	public final synchronized LineInfo getMessages(int lineNumber) {
		return this.messages.get(lineNumber);
	}

	/**
	 * Removes the specified message.
	 * 
	 * @param mInfo
	 *            The message to remove.
	 */
	public final void remove(MessageInfo mInfo) {
		int lineNumber = mInfo.getLineNumber();
		LineInfo lInfo = this.messages.get(lineNumber);
		if (lInfo != null) {
			lInfo.messages.remove(mInfo);
			if (lInfo.messages.size() == 0)
				this.messages.remove(lineNumber);
		}
	}

	public void clearMessages(MessageKind kind) {
		if (kind == null)
			this.messages.clear();
		else {
			for (LineInfo lInfo : messages.values()) {
				for (Iterator<MessageInfo> it = lInfo.messages.iterator(); it
						.hasNext();) {
					MessageInfo mInfo = it.next();
					if (mInfo.kind == kind)
						it.remove();
				}
			}
			for (Iterator<Map.Entry<Integer, LineInfo>> it = messages
					.entrySet().iterator(); it.hasNext();) {
				Map.Entry<Integer, LineInfo> eInfo = it.next();
				if (eInfo.getValue().messages.size() == 0)
					it.remove();
			}
		}
	}
}
