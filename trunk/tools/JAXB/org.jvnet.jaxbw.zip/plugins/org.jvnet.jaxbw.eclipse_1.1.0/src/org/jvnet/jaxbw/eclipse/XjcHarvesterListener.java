package org.jvnet.jaxbw.eclipse;

import java.util.*;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.ui.console.*;
import org.xml.sax.SAXParseException;

import com.sun.tools.xjc.XJCListener;

/**
 * XJC listener implementation. Collects messages and exceptions from the XJC
 * driver and:
 * <ul>
 * <li>Sends each {@link #message(String)} to the wizard pane (for progress
 * reports)</li>
 * <li>Processes each {@link #message(String)} for lines ending in
 * <code>.java</code> - the name of a generated file</li>
 * <li>Processes {@link #warning(SAXParseException)},
 * {@link #error(SAXParseException)} and {@link #fatalError(SAXParseException)}
 * and retrieves the information on the exception (filename, line number and the
 * text itself)</li>
 * </ul>.
 * 
 * @author Kirill Grouchnikov
 */
public class XjcHarvesterListener extends XJCListener {
	private IProgressMonitor monitor;

	/**
	 * All the messages reported by XJC driver (grouped by filename).
	 */
	private Map<String, FileInfo> messages;

	/**
	 * Names of all generated Java files.
	 */
	private List<String> generatedFileNames;

	protected MessageConsoleStream stream;

	/**
	 * Simple constructor.
	 */
	public XjcHarvesterListener(IProgressMonitor monitor) {
		super();
		this.monitor = monitor;
		this.messages = new HashMap<String, FileInfo>();
		this.generatedFileNames = new LinkedList<String>();

		MessageConsole console = new MessageConsole("JAXB 2.1 XJC Console", null);
		console.activate();
		ConsolePlugin.getDefault().getConsoleManager().addConsoles(
				new IConsole[] { console });
		stream = console.newMessageStream();
	}

	/**
	 * Adds XJC exception message.
	 * 
	 * @param filename
	 *            Name of the XSD schema.
	 * @param lineNumber
	 *            Line number of the message.
	 * @param kind
	 *            Message severity.
	 * @param text
	 *            Message text.
	 */
	private void addMessage(String filename, int lineNumber,
			FileInfo.MessageKind kind, String text) {
		if (filename == null)
			filename = "null";
		filename = FilePathInfo.normalize(filename);
		if (!this.messages.containsKey(filename)) {
			FileInfo fInfo = new FileInfo(filename);
			this.messages.put(filename, fInfo);
		}
		FileInfo fInfo = this.messages.get(filename);
		fInfo.addMessage(lineNumber - 1, kind, text);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.sun.tools.xjc.XJCListener#message(java.lang.String)
	 */
	public void message(String message) {
		this.monitor.subTask(message);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.sun.tools.xjc.XJCListener#generatedFile(java.lang.String)
	 */
	public void generatedFile(String s) {
		this.stream.println("/xjc/file/ " + s);
		if (s.endsWith("package-info.java"))
			return;
		generatedFileNames.add(s);
		this.monitor.subTask("Generated file '" + s + "'");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.xml.sax.ErrorHandler#error(org.xml.sax.SAXParseException)
	 */
	public void error(SAXParseException spe) {
		this.stream.println("/xjc/ Error " + "[" + spe.getSystemId() + ":"
				+ spe.getLineNumber() + "] " + spe.getMessage());
		this.addMessage(spe.getSystemId(), spe.getLineNumber(),
				FileInfo.MessageKind.ERROR, spe.getMessage());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.xml.sax.ErrorHandler#fatalError(org.xml.sax.SAXParseException)
	 */
	public void fatalError(SAXParseException spe) {
		this.stream.println("/xjc/ Fatal error " + "[" + spe.getSystemId() + ":"
				+ spe.getLineNumber() + "] " + spe.getMessage());
		this.addMessage(spe.getSystemId(), spe.getLineNumber(),
				FileInfo.MessageKind.ERROR, spe.getMessage());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.sun.tools.xjc.api.ErrorListener#info(org.xml.sax.SAXParseException)
	 */
	public void info(SAXParseException spe) {
		this.stream.println("/xjc/ Info " + "[" + spe.getSystemId() + ":"
				+ spe.getLineNumber() + "] " + spe.getMessage());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.xml.sax.ErrorHandler#warning(org.xml.sax.SAXParseException)
	 */
	public void warning(SAXParseException spe) {
		this.stream.println("/xjc/ Warning " + "[" + spe.getSystemId() + ":"
				+ spe.getLineNumber() + "] " + spe.getMessage());
		this.addMessage(spe.getSystemId(), spe.getLineNumber(),
				FileInfo.MessageKind.WARNING, spe.getMessage());
	}

	/**
	 * Retrieves all the messages reported by XJC driver (grouped by filename).
	 * 
	 * @return All the messages reported by XJC driver (grouped by filename).
	 */
	public Map<String, FileInfo> getMessages() {
		return messages;
	}

	/**
	 * Retrieves names of all generated Java files.
	 * 
	 * @return Names of all generated Java files.
	 */
	public List<String> getGeneratedFileNames() {
		return generatedFileNames;
	}

	@Override
	public boolean isCanceled() {
		return this.monitor.isCanceled();
	}
}
