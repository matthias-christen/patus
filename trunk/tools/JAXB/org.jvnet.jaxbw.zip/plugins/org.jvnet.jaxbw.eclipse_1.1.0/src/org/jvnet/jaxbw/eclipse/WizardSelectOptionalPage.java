package org.jvnet.jaxbw.eclipse;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.*;

public class WizardSelectOptionalPage extends WizardPage implements Listener {

	protected Text userClasspathText;

	protected String initialUserClasspath;

	protected Text catalogFilesText;

	protected String initialCatalogFiles;

	protected Text httpProxyText;

	protected String initialHttpProxy;

	protected Button doStrictValidationButton;

	protected boolean initialDoStrictValidation;

	protected Button allowExtensionsButton;

	protected boolean initialAllowExtensions;

	protected Button createReadOnlyFilesButton;

	protected boolean initialCreateReadOnlyFiles;

	public WizardSelectOptionalPage(String initialUserClasspath,
			String initialCatalogFiles, String initialHttpProxy,
			boolean initialDoStrictValidation, boolean initialAllowExtensions,
			boolean initialCreateReadOnlyFiles) {
		super("XJC optional parameters");
		this.setTitle("XJC optional parameters");
		this.initialUserClasspath = initialUserClasspath;
		this.initialCatalogFiles = initialCatalogFiles;
		this.initialHttpProxy = initialHttpProxy;
		this.initialDoStrictValidation = initialDoStrictValidation;
		this.initialAllowExtensions = initialAllowExtensions;
		this.initialCreateReadOnlyFiles = initialCreateReadOnlyFiles;
	}

	public void createControl(Composite parent) {
		final Group group = new Group(parent, SWT.NONE);
		GridLayout layout = new GridLayout();
		layout.numColumns = 2;
		group.setLayout(layout);

		Label labelUserClasspath = new Label(group, SWT.NONE);
		labelUserClasspath.setText("User class files");

		this.userClasspathText = new Text(group, SWT.BORDER);
		if (initialUserClasspath != null)
			this.userClasspathText.setText(initialUserClasspath);

		Label labelCatalogFiles = new Label(group, SWT.NONE);
		labelCatalogFiles.setText("Catalog files");

		this.catalogFilesText = new Text(group, SWT.BORDER);
		if (initialCatalogFiles != null)
			this.catalogFilesText.setText(initialCatalogFiles);

		Label labelHttpProxy = new Label(group, SWT.NONE);
		labelHttpProxy.setText("HTTP/HTTPS proxy");

		this.httpProxyText = new Text(group, SWT.BORDER);
		if (initialHttpProxy != null)
			this.httpProxyText.setText(initialHttpProxy);

		this.doStrictValidationButton = new Button(group, SWT.CHECK);
		this.doStrictValidationButton
				.setText("Do strict validation of input schema");
		this.doStrictValidationButton
				.setSelection(this.initialDoStrictValidation);

		this.allowExtensionsButton = new Button(group, SWT.CHECK);
		this.allowExtensionsButton.setText("Allow vendor extensions");
		this.allowExtensionsButton.setSelection(this.initialAllowExtensions);

		this.createReadOnlyFilesButton = new Button(group, SWT.CHECK);
		this.createReadOnlyFilesButton
				.setText("Generated files will be in read-only mode");
		this.createReadOnlyFilesButton
				.setSelection(this.initialCreateReadOnlyFiles);

		GridData data = new GridData();
		data.widthHint = 120;
		labelUserClasspath.setLayoutData(data);
		data = new GridData();
		data.widthHint = 120;
		labelCatalogFiles.setLayoutData(data);
		data = new GridData();
		data.widthHint = 120;
		labelHttpProxy.setLayoutData(data);

		GridData data2 = new GridData(GridData.FILL_HORIZONTAL);
		this.userClasspathText.setLayoutData(data2);
		data2 = new GridData(GridData.FILL_HORIZONTAL);
		this.catalogFilesText.setLayoutData(data2);
		data2 = new GridData(GridData.FILL_HORIZONTAL);
		this.httpProxyText.setLayoutData(data2);

		GridData data3 = new GridData();
		data3.horizontalSpan = 2;
		this.doStrictValidationButton.setLayoutData(data3);
		data3 = new GridData();
		data3.horizontalSpan = 2;
		this.createReadOnlyFilesButton.setLayoutData(data3);
		data3 = new GridData();
		data3.horizontalSpan = 2;
		this.allowExtensionsButton.setLayoutData(data3);

		setPageComplete(isPageComplete());

		this.setControl(group);
	}

	@Override
	public Control getControl() {
		return super.getControl();
	}

	public void handleEvent(Event event) {
		setPageComplete(isPageComplete());
	}

	@Override
	public boolean isPageComplete() {
		return true;
	}

	public String getUserClasspath() {
		String result = this.userClasspathText.getText();
		if (result == null)
			return null;
		if (result.length() == 0)
			return null;
		return result;
	}

	public boolean getAllowExtensions() {
		return this.allowExtensionsButton.getSelection();
	}

	public String getCatalogFiles() {
		String result = this.catalogFilesText.getText();
		if (result == null)
			return null;
		if (result.length() == 0)
			return null;
		return result;
	}

	public boolean getCreateReadOnlyFiles() {
		return this.createReadOnlyFilesButton.getSelection();
	}

	public boolean getDoStrictValidation() {
		return this.doStrictValidationButton.getSelection();
	}

	public String getHttpProxy() {
		String result = this.httpProxyText.getText();
		if (result == null)
			return null;
		if (result.length() == 0)
			return null;
		return result;
	}
}
