#ifndef __SSE_REDUCTIONS_H__
#define __SSE_REDUCTIONS_H__

#include "xmmintrin.h"
#include "emmintrin.h"

inline float vec_reduce_sum_ps (__m128 v)
{
}

inline float vec_reduce_product_ps (__m128 v)
{
}

inline float vec_reduce_min_ps (__m128 v)
{
}

inline float vec_reduce_max_ps (__m128 v)
{
}

#endif
