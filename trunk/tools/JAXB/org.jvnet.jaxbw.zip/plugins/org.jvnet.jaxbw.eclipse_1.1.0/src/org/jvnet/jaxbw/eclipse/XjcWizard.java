package org.jvnet.jaxbw.eclipse;

import java.util.LinkedList;

import org.eclipse.core.resources.IResource;
import org.eclipse.jface.dialogs.IDialogSettings;
import org.eclipse.jface.wizard.Wizard;

public class XjcWizard extends Wizard {
	public static final String PROP_PACKAGE_NAME = "xjc.package.name";

	public static final String PROP_OUTPUT_DIR = "xjc.output.dir";

	public static final String PROP_USER_CLASSPATH = "xjc.user.cp";

	public static final String PROP_CATALOG_FILES = "xjc.catalog.files";

	public static final String PROP_HTTP_PROXY = "xjc.http.proxy";

	public static final String PROP_DO_STRICT_VALIDATION = "xjc.strict.validation";

	public static final String PROP_ALLOW_EXTENSIONS = "xjc.allow.extensions";

	public static final String PROP_CREATE_RO_FILES = "xjc.create.ro.files";

	protected WizardSelectMandatoryPage mandatoryPage;

	protected WizardSelectOptionalPage optionalPage;

	protected IResource selectedResource;

	protected String[] xjcSettings;

	protected String outputDir;

	public XjcWizard(IResource selectedResource) {
		this.selectedResource = selectedResource;

		IDialogSettings settings = JaxbwPlugin.getDefault().getDialogSettings();
		String packageName = settings.get(PROP_PACKAGE_NAME);
		if (packageName == null)
			packageName = "org.example";
		String outputDir = settings.get(PROP_OUTPUT_DIR);
		this.mandatoryPage = new WizardSelectMandatoryPage(packageName,
				outputDir);

		String initialUserClasspath = settings.get(PROP_USER_CLASSPATH);
		String initialCatalogFiles = settings.get(PROP_CATALOG_FILES);
		String initialHttpProxy = settings.get(PROP_HTTP_PROXY);
		boolean initialDoStrictValidation = getBooleanProperty(settings,
				PROP_DO_STRICT_VALIDATION, true);
		boolean initialAllowExtensions = getBooleanProperty(settings,
				PROP_ALLOW_EXTENSIONS, false);
		boolean initialCreateReadOnlyFiles = getBooleanProperty(settings,
				PROP_CREATE_RO_FILES, false);
		this.optionalPage = new WizardSelectOptionalPage(initialUserClasspath,
				initialCatalogFiles, initialHttpProxy,
				initialDoStrictValidation, initialAllowExtensions,
				initialCreateReadOnlyFiles);

		this.addPage(this.mandatoryPage);
		this.addPage(this.optionalPage);
	}

	protected static boolean getBooleanProperty(IDialogSettings settings,
			String propertyName, boolean defaultValue) {
		String val = settings.get(propertyName);
		if (val == null)
			return defaultValue;
		if (val.length() == 0)
			return defaultValue;
		return settings.getBoolean(propertyName);
	}

	@Override
	public boolean performFinish() {
		this.outputDir = this.mandatoryPage.getOutputDir();

		IDialogSettings settings = JaxbwPlugin.getDefault().getDialogSettings();
		settings.put(PROP_PACKAGE_NAME, this.mandatoryPage.getPackageName());
		settings.put(PROP_OUTPUT_DIR, this.outputDir);
		settings.put(PROP_USER_CLASSPATH, this.optionalPage.getUserClasspath());
		settings.put(PROP_CATALOG_FILES, this.optionalPage.getCatalogFiles());
		settings.put(PROP_HTTP_PROXY, this.optionalPage.getHttpProxy());
		settings.put(PROP_DO_STRICT_VALIDATION, this.optionalPage
				.getDoStrictValidation());
		settings.put(PROP_ALLOW_EXTENSIONS, this.optionalPage
				.getAllowExtensions());
		settings.put(PROP_CREATE_RO_FILES, this.optionalPage
				.getCreateReadOnlyFiles());

		LinkedList<String> params = new LinkedList<String>();
		params.addLast(this.selectedResource.getLocation().toOSString());
		params.addLast("-d");
		params.addLast(this.outputDir);
		params.addLast("-p");
		params.addLast(this.mandatoryPage.getPackageName());

		if (!this.optionalPage.getDoStrictValidation())
			params.addLast("-nv");
		if (this.optionalPage.getAllowExtensions())
			params.addLast("-extension");
		if (this.optionalPage.getUserClasspath() != null) {
			params.addLast("-classpath");
			params.addLast(this.optionalPage.getUserClasspath());

		}
		if (this.optionalPage.getUserClasspath() != null) {
			params.addLast("-catalog");
			params.addLast(this.optionalPage.getUserClasspath());

		}
		if (this.optionalPage.getHttpProxy() != null) {
			params.addLast("-httpproxy");
			params.addLast(this.optionalPage.getHttpProxy());
		}
		if (this.optionalPage.getCreateReadOnlyFiles())
			params.addLast("-readOnly");

		this.xjcSettings = params.toArray(new String[0]);

		return true;
	}

	public String[] getXjcSettings() {
		return xjcSettings;
	}

	public String getOutputDir() {
		return this.outputDir;
	}
}
