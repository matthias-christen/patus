package org.jvnet.jaxbw.eclipse;

import java.io.File;
import java.util.StringTokenizer;

/**
 * Information on file location.
 * 
 * @author Kirill Grouchnikov
 */
public class FilePathInfo {
	/**
	 * Full path.
	 */
	private String fullPath;

	/**
	 * Relative path.
	 */
	private String relativePath;

	/**
	 * File name (in its directory).
	 */
	private String name;

	/**
	 * Normalizes the filename.
	 * 
	 * @param filename
	 *            Filename to normalize.
	 * @return Normalized filename.
	 */
	public static String normalize(String filename) {
		if (filename.startsWith("file:/"))
			filename = filename.substring(6);
		String result = filename.replace("/", File.separator).replace("\\",
				File.separator);
		return result.replace("%20", " ");
	}

	/**
	 * Retrieves directory path from the full path.
	 * 
	 * @param fullPath
	 *            Full path.
	 * @return Corresponding directory path.
	 */
	private static String getDirectoryPath(String fullPath) {
		// look for the last slash
		int lastSlashIndex = fullPath.lastIndexOf(File.separator);
		if (lastSlashIndex < 0) {
			return "";
		} else {
			return fullPath.substring(0, lastSlashIndex);
		}
	}

	/**
	 * Simple constructor.
	 * 
	 * @param fullPath
	 *            Full path.
	 */
	public FilePathInfo(String fullPath) {
		this.fullPath = FilePathInfo.normalize(fullPath);
		// look for the last slash
		int lastSlashIndex = this.fullPath.lastIndexOf(File.separator);
		if (lastSlashIndex < 0) {
			this.name = this.fullPath;
		} else {
			this.name = this.fullPath.substring(lastSlashIndex + 1);
		}
		this.relativePath = this.name;
	}

	/**
	 * Simple constructor.
	 * 
	 * @param referencePath
	 *            Reference path.
	 * @param relativePath
	 *            Relative path (relative to the reference path).
	 */
	public FilePathInfo(String referencePath, String relativePath) {
		relativePath = normalize(relativePath);

		StringTokenizer tokenizer = new StringTokenizer(relativePath, "/\\",
				false);
		String currName = getDirectoryPath(referencePath);

		String lastToken = "";
		while (tokenizer.hasMoreTokens()) {
			lastToken = tokenizer.nextToken();
			if (lastToken.compareTo(".") == 0) {
				continue;
			}
			if (lastToken.compareTo("..") == 0) {
				// up one directory
				int slInd = currName.lastIndexOf(File.separator);
				if (slInd < 0) {
					if (currName.length() == 0) {
						throw new IllegalArgumentException("Too many .. in '"
								+ relativePath + "' for '" + referencePath
								+ "'");
					} else {
						currName = "";
					}
				} else {
					currName = currName.substring(0, slInd);
				}
				continue;
			}
			if (currName.length() > 0) {
				currName += File.separator;
			}
			currName += lastToken;
		}

		this.fullPath = currName;
		this.relativePath = relativePath;

		// look for the last slash
		int lastSlashIndex = this.fullPath.lastIndexOf(File.separator);
		if (lastSlashIndex < 0) {
			this.name = this.fullPath;
		} else {
			this.name = this.fullPath.substring(lastSlashIndex + 1);
		}
	}

	/**
	 * Compares <code>this</code> path info with the specified path info.
	 * 
	 * @param path2
	 *            The path info to compare.
	 * @return <code>true</code> if both paths are resolved to the same
	 *         location, <code>false</code> otherwise.
	 */
	public boolean isSame(FilePathInfo path2) {
		return this.fullPath.equals(path2.fullPath);
	}

	/**
	 * Retrieves the full path of <code>this</code> object.
	 * 
	 * @return The full path of <code>this</code> object.
	 */
	public String getFullPath() {
		return fullPath;
	}

	/**
	 * Retrieves the file name of <code>this</code> object.
	 * 
	 * @return The file name of <code>this</code> object.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Retrieves the relative path of <code>this</code> object.
	 * 
	 * @return The relative path of <code>this</code> object.
	 */
	public String getRelativePath() {
		return relativePath;
	}

}
